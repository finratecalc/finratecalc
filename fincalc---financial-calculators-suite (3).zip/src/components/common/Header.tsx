import React, { useState } from 'react';
import {
  Globe,
  Printer,
  Shield,
  Home,
  CreditCard,
  TrendingUp,
  Car,
  Clock,
  DollarSign,
  Grid,
  Scale,
  Menu,
  X,
  FileDown,
} from 'lucide-react';
import {
  CalculatorId,
  CurrencyCode,
  SUPPORTED_CURRENCIES,
  CalculationHistoryItem,
} from '../../types/financial';
import { RecentCalculationsDropdown } from './RecentCalculationsDropdown';
import { MarketBenchmarksBar } from './MarketBenchmarksBar';
import { MarketBenchmark } from '../../services/marketRatesService';

interface HeaderProps {
  activeCalculator: CalculatorId | 'directory';
  onSelectCalculator: (id: CalculatorId | 'directory') => void;
  currency: CurrencyCode;
  onCurrencyChange: (code: CurrencyCode) => void;
  onOpenReport?: () => void;
  onRestoreCalculation?: (item: CalculationHistoryItem) => void;
  onApplyBenchmark?: (benchmark: MarketBenchmark) => void;
  onOpenCompare?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeCalculator,
  onSelectCalculator,
  currency,
  onCurrencyChange,
  onOpenReport,
  onRestoreCalculation,
  onApplyBenchmark,
  onOpenCompare,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const mainNavItems: { id: CalculatorId | 'directory'; label: string; icon: React.ReactNode }[] = [
    { id: 'mortgage', label: 'Mortgage', icon: <Home className="w-3.5 h-3.5" /> },
    { id: 'loan', label: 'Personal Loan', icon: <CreditCard className="w-3.5 h-3.5" /> },
    { id: 'auto-loan', label: 'Auto Loan', icon: <Car className="w-3.5 h-3.5" /> },
    { id: 'investment', label: 'Compound', icon: <TrendingUp className="w-3.5 h-3.5" /> },
    { id: 'retirement', label: '401(k)', icon: <Clock className="w-3.5 h-3.5" /> },
    { id: 'salary', label: 'Take-Home', icon: <DollarSign className="w-3.5 h-3.5" /> },
    { id: 'directory', label: 'All 8 Tools', icon: <Grid className="w-3.5 h-3.5" /> },
  ];

  const handleNavClick = (id: CalculatorId | 'directory') => {
    onSelectCalculator(id);
    setMobileMenuOpen(false);
  };

  return (
    <>
      {/* Top Regional Market Rates Ticker Bar */}
      <MarketBenchmarksBar
        currency={currency}
        onSelectCalculator={(id) => onSelectCalculator(id)}
        onApplyBenchmark={onApplyBenchmark}
      />

      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/90 shadow-2xs print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-3">
          {/* Brand Logo & Wordmark */}
          <button
            onClick={() => handleNavClick('directory')}
            className="flex items-center gap-2.5 group text-left shrink-0 cursor-pointer"
            title="FinRateCalc.com - Precision Financial Calculator Suite"
          >
            <div className="w-9 h-9 rounded-xl bg-slate-900 text-emerald-400 flex items-center justify-center font-bold shadow-xs border border-slate-800 group-hover:bg-slate-800 transition-colors">
              <Shield className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-1 leading-none">
                <span className="text-lg font-black tracking-tight text-slate-900">
                  FinRate<span className="text-emerald-600">Calc</span>
                </span>
                <span className="text-[10px] font-bold text-slate-400 font-mono tracking-tighter">
                  .com
                </span>
              </div>
              <span className="text-[9px] font-semibold text-slate-500 uppercase tracking-wider leading-none mt-1">
                Precision Financial Suite
              </span>
            </div>
          </button>

          {/* Central Segmented Calculator Navigation (Desktop) */}
          <nav className="hidden lg:flex items-center gap-1 bg-slate-100/90 p-1 rounded-xl border border-slate-200/70">
            {mainNavItems.map((item) => {
              const isActive = activeCalculator === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-all duration-150 cursor-pointer ${
                    isActive
                      ? 'bg-white text-slate-950 shadow-xs font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  <span className={isActive ? 'text-emerald-600' : 'text-slate-400'}>
                    {item.icon}
                  </span>
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Action Tools */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Compare Scenarios Button */}
            {onOpenCompare && (
              <button
                onClick={onOpenCompare}
                className="hidden xl:flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200/90 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer shadow-2xs"
                title="Compare 2 Financial Scenarios Side by Side"
              >
                <Scale className="w-3.5 h-3.5 text-emerald-600" />
                <span>Compare</span>
              </button>
            )}

            {/* Recent Calculations Dropdown Menu */}
            {onRestoreCalculation && (
              <RecentCalculationsDropdown onRestoreCalculation={onRestoreCalculation} />
            )}

            {/* Currency Selector */}
            <div className="relative flex items-center">
              <Globe className="w-3.5 h-3.5 text-slate-400 absolute left-2 pointer-events-none" />
              <select
                value={currency}
                onChange={(e) => onCurrencyChange(e.target.value as CurrencyCode)}
                className="pl-7 pr-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 border-0 rounded-lg focus:ring-2 focus:ring-emerald-500 cursor-pointer transition-colors"
                title="Change Currency"
              >
                {SUPPORTED_CURRENCIES.map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.code} ({c.symbol.trim()})
                  </option>
                ))}
              </select>
            </div>

            {/* PDF Report Trigger */}
            {onOpenReport && activeCalculator !== 'directory' && (
              <button
                onClick={onOpenReport}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs transition-colors whitespace-nowrap cursor-pointer"
                title="Download formatted statement as PDF"
              >
                <FileDown className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">PDF Report</span>
              </button>
            )}

            {/* Mobile Menu Toggle Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-4 shadow-lg animate-in slide-in-from-top-2">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
              Financial Calculators
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {mainNavItems.map((item) => {
                const isActive = activeCalculator === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`flex items-center gap-2 px-3 py-2 text-xs font-medium rounded-lg text-left transition-colors cursor-pointer ${
                      isActive
                        ? 'bg-slate-900 text-white font-semibold'
                        : 'text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <span>{item.icon}</span>
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
            {onOpenCompare && (
              <div className="mt-3 pt-3 border-t border-slate-100">
                <button
                  onClick={() => {
                    onOpenCompare();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-semibold text-emerald-800 bg-emerald-50 rounded-lg hover:bg-emerald-100 transition-colors"
                >
                  <Scale className="w-4 h-4 text-emerald-600" />
                  <span>Compare 2 Scenarios Side by Side</span>
                </button>
              </div>
            )}
          </div>
        )}
      </header>
    </>
  );
};
