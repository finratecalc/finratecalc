import React from 'react';
import { X, ShieldCheck, FileText, AlertTriangle, Mail } from 'lucide-react';

export type LegalDocType = 'privacy' | 'terms' | 'disclaimer' | 'contact' | 'about';

interface LegalModalProps {
  type: LegalDocType | null;
  onClose: () => void;
}

export const LegalModal: React.FC<LegalModalProps> = ({ type, onClose }) => {
  if (!type) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white text-slate-900 border border-slate-200 rounded-2xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2">
            {type === 'privacy' && <ShieldCheck className="w-5 h-5 text-emerald-600" />}
            {type === 'terms' && <FileText className="w-5 h-5 text-blue-600" />}
            {type === 'disclaimer' && <AlertTriangle className="w-5 h-5 text-amber-600" />}
            {type === 'contact' && <Mail className="w-5 h-5 text-indigo-600" />}
            {type === 'about' && <ShieldCheck className="w-5 h-5 text-emerald-600" />}

            <h3 className="text-base font-bold text-slate-900 capitalize">
              {type === 'privacy' && 'Privacy Policy'}
              {type === 'terms' && 'Terms of Service'}
              {type === 'disclaimer' && 'Financial & Legal Disclaimer'}
              {type === 'contact' && 'Contact Us'}
              {type === 'about' && 'About FinRateCalc.com'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs text-slate-600 leading-relaxed font-sans">
          {type === 'privacy' && (
            <>
              <p className="font-semibold text-slate-900">Last Updated: October 2026</p>
              <h4 className="text-sm font-bold text-slate-900">1. Client-Side Privacy Guarantee</h4>
              <p>
                At <strong>FinRateCalc.com</strong>, your privacy is our highest priority. All mathematical calculations, financial figures, salaries, down payments, and loan amounts entered into our calculators are processed strictly inside your web browser (client-side execution). <strong>We do not transmit, log, sell, or store your private financial data on external servers.</strong>
              </p>

              <h4 className="text-sm font-bold text-slate-900">2. Cookies & Local Storage</h4>
              <p>
                We use browser <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-[11px]">localStorage</code> solely to allow you to save your recent calculations and preserve your preferred currency settings across browser sessions. You may clear this local data at any time via your browser settings or our "Clear All" buttons.
              </p>

              <h4 className="text-sm font-bold text-slate-900">3. Third-Party Analytics & Advertising</h4>
              <p>
                We may use standard web analytics (such as Google Analytics) and privacy-compliant advertising networks (such as Google AdSense) to display non-personalized or contextual advertising. These providers may collect anonymized technical details such as your device type and IP address in compliance with CCPA and GDPR regulations.
              </p>

              <h4 className="text-sm font-bold text-slate-900">4. Contact Concerning Privacy</h4>
              <p>
                If you have any questions regarding this Privacy Policy, please reach out via our contact page at <span className="font-semibold text-slate-900">support@finratecalc.com</span>.
              </p>
            </>
          )}

          {type === 'terms' && (
            <>
              <p className="font-semibold text-slate-900">Effective Date: October 2026</p>
              <h4 className="text-sm font-bold text-slate-900">1. Acceptance of Terms</h4>
              <p>
                By accessing and using <strong>FinRateCalc.com</strong>, you accept and agree to be bound by these Terms of Service. If you do not agree with any part of these terms, please do not use our services.
              </p>

              <h4 className="text-sm font-bold text-slate-900">2. Informational & Educational Use Only</h4>
              <p>
                All calculators, benchmark rates, charts, PDF reports, and educational guides provided on FinRateCalc.com are intended exclusively for general personal informational, research, and estimation purposes. Nothing contained on this site constitutes binding loan offers, legal advice, tax planning, or certified financial advisory services.
              </p>

              <h4 className="text-sm font-bold text-slate-900">3. Intellectual Property</h4>
              <p>
                The design, algorithms, layout, graphics, and custom code of FinRateCalc.com are the proprietary property of FinRateCalc.com and are protected by applicable copyright, trademark, and intellectual property laws.
              </p>

              <h4 className="text-sm font-bold text-slate-900">4. Limitation of Liability</h4>
              <p>
                In no event shall FinRateCalc.com or its operators be held liable for any financial decisions, losses, damages, or discrepancies resulting from the use of or reliance on our calculation models.
              </p>
            </>
          )}

          {type === 'disclaimer' && (
            <>
              <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 space-y-1">
                <span className="font-bold text-xs flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-700" />
                  Not a Financial Advisory or Lending Institution
                </span>
                <p className="text-[11px] leading-relaxed">
                  FinRateCalc.com is an independent financial technology analytics tool. We are not a bank, mortgage lender, broker, investment adviser, or licensed Certified Public Accountant (CPA).
                </p>
              </div>

              <h4 className="text-sm font-bold text-slate-900">1. Estimation & Mathematical Models</h4>
              <p>
                Mortgage and loan amortization schedules reflect standard Consumer Financial Protection Bureau (CFPB) mathematical algorithms. Real-world lender quotes will vary based on individual credit scores (FICO), underwriting guidelines, loan origination points, appraisal fees, and daily secondary market bond movements.
              </p>

              <h4 className="text-sm font-bold text-slate-900">2. Tax Calculations</h4>
              <p>
                Salary and take-home pay calculations estimate federal income tax, Social Security, Medicare (FICA), and standard state deductions based on current statutory tax brackets. Consult a licensed tax professional or CPA for personalized filing advice.
              </p>

              <h4 className="text-sm font-bold text-slate-900">3. Investment Projections</h4>
              <p>
                Historical market returns (such as the S&P 500 average) do not guarantee future performance. Actual investment returns fluctuate with market volatility.
              </p>
            </>
          )}

          {type === 'about' && (
            <>
              <h4 className="text-sm font-bold text-slate-900">About FinRateCalc.com</h4>
              <p>
                <strong>FinRateCalc.com</strong> was founded with a single mission: to provide American consumers, homebuyers, borrowers, and investors with bank-grade financial calculators without annoying paywalls, forced email sign-ups, or invasive tracking.
              </p>

              <h4 className="text-sm font-bold text-slate-900">Our Core Principles:</h4>
              <ul className="list-disc pl-5 space-y-1.5">
                <li><strong>100% Client-Side Privacy:</strong> Your financial numbers never leave your personal computer or mobile phone.</li>
                <li><strong>Official Market Benchmarks:</strong> Live references to Freddie Mac PMMS, Federal Reserve H.15, IRS Section 402(g), and Bureau of Labor Statistics (BLS) CPI inflation.</li>
                <li><strong>Actuarial Accuracy:</strong> Every formula adheres to standard US banking standards (CFPB Regulation Z).</li>
                <li><strong>Institutional PDF Reporting:</strong> Clean, executive-ready PDF statement generation for your loan applications or financial planner discussions.</li>
              </ul>
            </>
          )}

          {type === 'contact' && (
            <>
              <p>
                We welcome feedback, partnership inquiries, and feature suggestions from our users and financial industry professionals.
              </p>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">General Support & Feedback</span>
                    <a href="mailto:support@finratecalc.com" className="text-xs text-emerald-700 hover:underline font-mono">
                      support@finratecalc.com
                    </a>
                  </div>
                </div>

                <div className="flex items-center gap-3 pt-2 border-t border-slate-200">
                  <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-800 flex items-center justify-center font-bold">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">Editorial & Business Partnerships</span>
                    <a href="mailto:partners@finratecalc.com" className="text-xs text-blue-700 hover:underline font-mono">
                      partners@finratecalc.com
                    </a>
                  </div>
                </div>
              </div>

              <p className="text-[11px] text-slate-500">
                Our team responds to all inquiries within 24 to 48 business hours.
              </p>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <span className="text-[11px] text-slate-400 font-mono">FinRateCalc.com Official Documentation</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
